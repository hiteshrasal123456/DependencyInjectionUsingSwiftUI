//
//  ItemRow.swift
//  IDine
//
//  Created by Tejora on 31/03/2020.
//  Copyright © 2020 Tejora. All rights reserved.
//

import SwiftUI

struct ItemRow: View {
    var item: MenuItem
    var body: some View {
        //Dependency injection
        NavigationLink(destination: ItemDetail(item: item)) {
        HStack {
            Image(item.thumbnailImage)
            .clipShape(Circle())
            .overlay(Circle().stroke(Color.gray, lineWidth: 2))
            VStack(alignment: .leading) {
                Text(item.name)
                .font(.headline)
                Text("$\(item.price)")
            }
        }
       }
    }
}

struct ItemRow_Previews: PreviewProvider {
    static var previews: some View {
        ItemRow(item: MenuItem.example)
    }
}
